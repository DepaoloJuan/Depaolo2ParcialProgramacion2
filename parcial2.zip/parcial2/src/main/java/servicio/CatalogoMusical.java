
package servicio;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;

/**
 *
 * @author juanm
 */
public class CatalogoMusical <T extends  Comparable <? super T> & interfaz.CSVSerializable> implements Iterable<T>, Serializable{
    
    private static final long serialVersionUID = 1L;
    private  List<T> elementos;
    
    public CatalogoMusical(){
        elementos = new ArrayList<>();
    }
    
    public  void agregar(T item){
        elementos.add(item);
        
    }
    
    public T obtener(int indice){
        return elementos.get(indice);
    }
    
    public void eliminar(int indice){
        elementos.remove(indice);
    }
    
    public List <T> filtrar(Predicate<T> criterio){
        List<T> resultado = new ArrayList<>();
        for (T item : elementos){
            if (criterio.test(item)){
                resultado.add(item);
            }
        }
        return resultado;
    }
    
    public void ordenar(){
        Collections.sort(elementos);
        
    }
    
    public void ordenar(Comparator<? super T> comparador){
        elementos.sort(comparador);
    }
    
    public void paraCadaElemento(Consumer<T> accion){
        for (T item : elementos) {
            accion.accept(item);
        }
    }
    
    public void cargarDesdeArchivo(String ruta)throws IOException, ClassNotFoundException{
        
        try (ObjectInputStream objetoIStream = new ObjectInputStream(new FileInputStream(ruta))){
            CatalogoMusical<T> cargado = (CatalogoMusical < T >) objetoIStream.readObject();
            this.elementos = cargado.elementos;
        }
        
    }
    
    public void guardarEnArchivo(String ruta) throws IOException{
        try(ObjectOutputStream objectOStream = new ObjectOutputStream(new FileOutputStream(ruta))){
           objectOStream.writeObject(this);
        }
    }
    
    public void guardarEnCSV(String ruta) throws IOException{
        try(BufferedWriter bw = new BufferedWriter(new FileWriter(ruta))){
            for (T item : elementos) {
                bw.write(item.toCSV());
                bw.newLine();
            }
        }
    }
    
    public void cargarDesdeCSV(String ruta, java.util.function.Function<String,T> fromCSV) throws IOException{
       
        elementos.clear();
        try(BufferedReader br = new BufferedReader(new FileReader(ruta))){
            String linea;
            while ((linea = br.readLine()) != null){
                elementos.add(fromCSV.apply(linea));
            }
        }
    }
    
    @Override
    public Iterator<T> iterator(){
        return elementos.iterator();
    }

    
}
