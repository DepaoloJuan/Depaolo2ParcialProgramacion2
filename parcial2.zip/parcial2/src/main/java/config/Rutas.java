
package config;

/**
 *
 * @author juanm
 */
public interface Rutas {
     String BINARIO = "src/main/java/data/canciones.dat";
    String CSV = "src/main/java/data/canciones.csv";
}
