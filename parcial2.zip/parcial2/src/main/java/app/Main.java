

package app;

import config.Rutas;
import java.io.IOException;
import model.Cancion;
import model.GeneroMusical;
import servicio.CatalogoMusical;

/**
 *
 * @author juanm
 */
public class Main {

    public static void main(String[] args) {
        
     try { 
            CatalogoMusical<Cancion> catalogo = new CatalogoMusical<>(); 
            catalogo.agregar(new Cancion(1, "Bohemian Rhapsody", "Queen", GeneroMusical.ROCK)); 
            catalogo.agregar(new Cancion(2, "Billie Jean", "Michael Jackson", GeneroMusical.POP)); 
            catalogo.agregar(new Cancion(3, "Shape of You", "Ed Sheeran", GeneroMusical.POP)); 
            catalogo.agregar(new Cancion(4, "Take Five", "Dave Brubeck", GeneroMusical.JAZZ)); 
            catalogo.agregar(new Cancion(5, "Canon in D", "Pachelbel", GeneroMusical.CLASICA)); 
 
            System.out.println("Catálogo de canciones:"); 
            catalogo.paraCadaElemento(System.out::println); 
 
            System.out.println("\nCanciones de género POP:"); 
            catalogo.filtrar(c -> c.getGenero() == GeneroMusical.POP) 
                    .forEach(System.out::println); 
 
            System.out.println("\nCanciones cuyo título contiene 'shape':"); 
            catalogo.filtrar(c -> c.getTitulo().toLowerCase().contains("shape")) 
                    .forEach(System.out::println); 
 
            System.out.println("\nCanciones ordenadas por ID:"); 
            catalogo.ordenar(); 
            catalogo.paraCadaElemento(System.out::println); 
 
            System.out.println("\nCanciones ordenadas por artista:"); 
            catalogo.ordenar(( c1, c2) -> c1.getArtista().compareTo(c2.getArtista())); 
            catalogo.paraCadaElemento(System.out::println); 
 
            catalogo.guardarEnArchivo(Rutas.BINARIO); 
 
            CatalogoMusical<Cancion> cargado = new CatalogoMusical<>(); 
            cargado.cargarDesdeArchivo(Rutas.BINARIO); 
            System.out.println("\nCanciones cargadas desde binario:"); 
            cargado.paraCadaElemento(System.out::println); 
 
            catalogo.guardarEnCSV(Rutas.CSV); 
 
            cargado.cargarDesdeCSV(Rutas.CSV, Cancion::fromCSV); 
            System.out.println("\nCanciones cargadas desde CSV:"); 
            cargado.paraCadaElemento(System.out::println); 
 
           } catch (IOException | ClassNotFoundException e) { 
            System.err.println("Error: " + e.getMessage()); 
        } 
    } 
}   
        
        
        
        
       