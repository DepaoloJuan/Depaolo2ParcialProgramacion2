
package model;

import interfaz.CSVSerializable;
import java.io.Serializable;

/**
 *
 * @author juanm
 */
public class Cancion implements Comparable<Cancion>, CSVSerializable, Serializable{
    
    private static final long serialVersionUID = 1L;
    
    private  int id;
    private String titulo;
    private String artista;
    private GeneroMusical genero;
    
    public Cancion(int id, String titulo, String artista, GeneroMusical genero){
        
        this.id = id;
        this.titulo = titulo;
        this.artista = artista;
        this.genero = genero;
        
        
    }
    
    public static Cancion fromCSV(String linea){
        String [] datos = linea.split(",");
        return new Cancion(
                Integer.parseInt(datos[0]),
                datos[1], datos[2],
                GeneroMusical.valueOf(datos[3]));
    }

    @Override
    public int compareTo(Cancion otra) {
        return Integer.compare(otra.id, this.id);
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + artista + "," + genero;
    }
    
    @Override
    public String toString(){
      return "Cancion{id=" + id + ", titulo='" + titulo + "', artista='" + artista + "', genero=" + genero + "}";  
    }
    
    public GeneroMusical getGenero(){
        return genero;
    }
    
    public String getTitulo(){
        return titulo;
    }
    
    public String getArtista(){
        return artista;
    }
    
    
    
}
