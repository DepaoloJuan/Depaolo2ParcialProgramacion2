
package model;

import java.util.concurrent.locks.ReentrantReadWriteLock;

/**
 *
 * @author juanm
 */
public enum GeneroMusical {
    ROCK, POP, JAZZ, CLASICA, ELECTRONICA, REGGAETON 
}
