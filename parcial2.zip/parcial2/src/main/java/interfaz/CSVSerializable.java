
package interfaz;

/**
 *
 * @author juanm
 */
public interface CSVSerializable {
    
    String toCSV();
}
